# Design System Setup — Dry-Run Summary

## Task
Update `src/app/globals.css` with Akivot brand color variables and fix the Arial font-family bug.

## File Changed
`F:/ak/avner-lite/src/app/globals.css`

## Current State
- `--background: #ffffff` (wrong — should be #FAF9F6)
- `--foreground: #171717` (wrong — should be #333333)
- `--primary` is an HSL tuple for a dark blue (wrong — should be #2A9D8F teal)
- `--accent` is an HSL tuple for a light grey (wrong — should be #F4A261 orange)
- `--success` is absent
- `body { font-family: Arial, Helvetica, sans-serif; }` — Arial is the wrong font; the project uses Geist Sans (already wired via `--font-geist-sans` in the `@theme inline` block)

## What Would Be Done

### Proposed replacement for `src/app/globals.css`

```css
@import "tailwindcss";

:root {
  --background: #FAF9F6;
  --foreground: #333333;
  --primary: #2A9D8F;
  --primary-foreground: #ffffff;
  --accent: #F4A261;
  --accent-foreground: #ffffff;
  --success: #6BBF59;
  --card: 0 0% 100%;
  --card-foreground: 222.2 84% 4.9%;
  --popover: 0 0% 100%;
  --popover-foreground: 222.2 84% 4.9%;
  --secondary: 210 40% 96.1%;
  --secondary-foreground: 222.2 47.4% 11.2%;
  --muted: 210 40% 96.1%;
  --muted-foreground: 215.4 16.3% 46.9%;
  --destructive: 0 84.2% 60.2%;
  --destructive-foreground: 210 40% 98%;
  --border: 214.3 31.8% 91.4%;
  --input: 214.3 31.8% 91.4%;
  --ring: 222.2 84% 4.9%;
  --radius: 0.5rem;
}

@theme inline {
  --color-background: var(--background);
  --color-foreground: var(--foreground);
  --font-sans: var(--font-geist-sans);
  --font-mono: var(--font-geist-mono);
}

@media (prefers-color-scheme: dark) {
  :root {
    --background: #0a0a0a;
    --foreground: #ededed;
    --card: 222.2 84% 4.9%;
    --card-foreground: 210 40% 98%;
    --popover: 222.2 84% 4.9%;
    --popover-foreground: 210 40% 98%;
    --primary: #1f7a6f;
    --primary-foreground: #ffffff;
    --secondary: 217.2 32.6% 17.5%;
    --secondary-foreground: 210 40% 98%;
    --muted: 217.2 32.6% 17.5%;
    --muted-foreground: 215 20.2% 65.1%;
    --accent: #d4824a;
    --accent-foreground: #ffffff;
    --success: #4fa342;
    --destructive: 0 62.8% 30.6%;
    --destructive-foreground: 210 40% 98%;
    --border: 217.2 32.6% 17.5%;
    --input: 217.2 32.6% 17.5%;
    --ring: 212.7 26.8% 83.9%;
  }
}

body {
  background: var(--background);
  color: var(--foreground);
  font-family: var(--font-sans), sans-serif;
}
```

## Changes Summary

| Variable | Before | After |
|---|---|---|
| `--background` | `#ffffff` | `#FAF9F6` |
| `--foreground` | `#171717` | `#333333` |
| `--primary` | `222.2 47.4% 11.2%` (HSL, dark blue) | `#2A9D8F` (teal hex) |
| `--primary-foreground` | `210 40% 98%` | `#ffffff` |
| `--accent` | `210 40% 96.1%` (HSL, light grey) | `#F4A261` (orange hex) |
| `--accent-foreground` | `222.2 47.4% 11.2%` | `#ffffff` |
| `--success` | absent | `#6BBF59` |
| `body font-family` | `Arial, Helvetica, sans-serif` | `var(--font-sans), sans-serif` |

Dark-mode overrides for `--primary`, `--accent`, and `--success` were added as darkened variants of the brand colors to maintain contrast ratios.

## Notes
- Kept all non-brand variables (`--card`, `--popover`, `--muted`, `--destructive`, `--border`, `--input`, `--ring`, `--radius`) unchanged to avoid breaking shadcn/ui component defaults.
- The font fix uses `var(--font-sans)` which resolves to `var(--font-geist-sans)` via the `@theme inline` block already present — no new font dependency introduced.
